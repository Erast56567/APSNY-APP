-- Apsny Avto database setup for Supabase (SQL Editor)
create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  brand text not null,
  model text not null,
  year int not null check (year between 1950 and 2027),
  price numeric(14,2) not null check (price > 0),
  mileage int check (mileage is null or mileage >= 0),
  city text not null,
  phone text not null,
  description text default '',
  photo_url text,
  status text not null default 'published' check (status in ('published','hidden','sold')),
  created_at timestamptz not null default now()
);
alter table public.listings enable row level security;
drop policy if exists "Published listings are public" on public.listings;
create policy "Published listings are public" on public.listings for select using (status='published' or auth.uid()=user_id);
drop policy if exists "Users create own listings" on public.listings;
create policy "Users create own listings" on public.listings for insert to authenticated with check (auth.uid()=user_id);
drop policy if exists "Users update own listings" on public.listings;
create policy "Users update own listings" on public.listings for update to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
drop policy if exists "Users delete own listings" on public.listings;
create policy "Users delete own listings" on public.listings for delete to authenticated using (auth.uid()=user_id);

-- Public image bucket; upload/delete is restricted to each user's own folder.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('car-photos','car-photos',true,8388608,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true, file_size_limit=8388608;
drop policy if exists "Public can view car photos" on storage.objects;
create policy "Public can view car photos" on storage.objects for select using (bucket_id='car-photos');
drop policy if exists "Users upload own car photos" on storage.objects;
create policy "Users upload own car photos" on storage.objects for insert to authenticated with check (bucket_id='car-photos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Users delete own car photos" on storage.objects;
create policy "Users delete own car photos" on storage.objects for delete to authenticated using (bucket_id='car-photos' and (storage.foldername(name))[1]=auth.uid()::text);

create index if not exists listings_created_at_idx on public.listings(created_at desc);
create index if not exists listings_city_idx on public.listings(city);
create index if not exists listings_brand_model_idx on public.listings(brand,model);
