// Apsny Avto — client app. Set SUPABASE_URL and SUPABASE_ANON_KEY after creating a project.
const SUPABASE_URL = ""; // e.g. https://xxxx.supabase.co
const SUPABASE_ANON_KEY = ""; // public anon key only; NEVER put service_role key here
const hasBackend = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase);
const db = hasBackend ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const $ = s => document.querySelector(s);
let currentUser = null, allListings = [];
const demo = [
 {id:"d1",brand:"Mercedes-Benz",model:"E-Класс",year:2017,price:2350000,mileage:98000,city:"Сухум",description:"Хорошее состояние. Подробности по телефону.",phone:"+7 (940) 000-00-00",created_at:new Date().toISOString()},
 {id:"d2",brand:"Toyota",model:"Camry",year:2015,price:1780000,mileage:135000,city:"Гагра",description:"Ухоженный автомобиль.",phone:"+7 (940) 000-00-00",created_at:new Date(Date.now()-86400000).toISOString()},
 {id:"d3",brand:"BMW",model:"X5",year:2019,price:4200000,mileage:76000,city:"Гудаута",description:"Комплектация и состояние — по запросу.",phone:"+7 (940) 000-00-00",created_at:new Date(Date.now()-172800000).toISOString()}
];
function money(n){return new Intl.NumberFormat("ru-RU").format(Number(n)||0)+" ₽"}
function toast(s){const t=$("#toast");t.textContent=s;t.style.display="block";setTimeout(()=>t.style.display="none",3200)}
function show(id){$("#"+id).classList.add("show")} function hide(id){$("#"+id).classList.remove("show")}
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>hide(b.dataset.close));
$("#addTop").onclick=$("#heroAdd").onclick=()=>{if(!db){toast("Сначала подключите сервер Supabase — инструкция в README");return} if(!currentUser){show("authModal");return}show("listingModal")};
document.querySelector('[data-tab="add"]').onclick=()=>$("#addTop").click();
$("#loginBtn").onclick=()=>show("authModal");
document.querySelector('[data-tab="account"]').onclick=()=>{renderAccount();show("accountModal")};
document.querySelector('[data-tab="home"]').onclick=()=>window.scrollTo({top:0,behavior:"smooth"});
function renderAccount(){const el=$("#accountInfo");el.innerHTML=currentUser?`<p>Вы вошли как <b>${currentUser.email}</b></p><button class="btn" id="logout">Выйти</button>`:`<p>Вы не вошли в аккаунт.</p><button class="btn gold" id="openAuth">Войти / зарегистрироваться</button>`;$("#logout")?.addEventListener("click",async()=>{await db.auth.signOut();currentUser=null;renderAccount();toast("Вы вышли из аккаунта")});$("#openAuth")?.addEventListener("click",()=>{hide("accountModal");show("authModal")})}
async function loadListings(){
 if(!db){allListings=demo;$("#count").textContent="Демонстрация";renderListings();return}
 const {data,error}=await db.from("listings").select("*").eq("status","published").order("created_at",{ascending:false}).limit(100);
 if(error){$("#count").textContent="Ошибка загрузки";$("#listings").innerHTML='<div class="empty">Не удалось загрузить объявления. Проверьте настройки сервера.</div>';return}
 allListings=data||[];$("#count").textContent=allListings.length+" объявлений";renderListings();
}
function renderListings(){
 const q=$("#q").value.trim().toLowerCase(), city=$("#city").value, sort=$("#sort").value;
 let rows=allListings.filter(x=>(!q||`${x.brand} ${x.model}`.toLowerCase().includes(q))&&(!city||x.city===city));
 if(sort==="cheap")rows.sort((a,b)=>a.price-b.price);if(sort==="expensive")rows.sort((a,b)=>b.price-a.price);
 $("#count").textContent=hasBackend?rows.length+" объявлений":"Демо · "+rows.length+" авто";
 $("#listings").innerHTML=rows.length?rows.map(x=>`<article class="car"><div class="photo">${x.photo_url?`<img src="${esc(x.photo_url)}" alt="${esc(x.brand)} ${esc(x.model)}">`:'<div class="placeholder">🚘</div>'}<span class="tag">${esc(x.city||"Абхазия")}</span></div><div class="car-body"><h3>${esc(x.brand)} ${esc(x.model)}</h3><div class="specs"><span>${x.year||"—"} г.</span><span>${x.mileage?Number(x.mileage).toLocaleString("ru-RU")+" км":"Пробег не указан"}</span></div><div class="price">${money(x.price)}</div><div class="location"><span>${esc(x.description||"Без описания").slice(0,56)}</span><a href="tel:${esc((x.phone||"").replace(/[^+0-9]/g,""))}" style="color:var(--gold2);white-space:nowrap">Позвонить</a></div></div></article>`).join(""):'<div class="empty">Пока нет объявлений по этому запросу. Будьте первым!</div>';
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("#searchBtn").onclick=renderListings;$("#q").oninput=renderListings;$("#city").onchange=renderListings;$("#sort").onchange=renderListings;
$("#authForm").onsubmit=async e=>{e.preventDefault();if(!db){toast("Сервер ещё не подключён. Смотрите README.");return}const email=new FormData(e.target).get("email");const {error}=await db.auth.signInWithOtp({email,options:{emailRedirectTo:location.origin}});$("#authHint").textContent=error?error.message:"Ссылка отправлена на почту. Откройте её на этом устройстве.";};
$("#listingForm").onsubmit=async e=>{
 e.preventDefault();if(!db||!currentUser){toast("Нужно подключить сервер и войти");return}
 const f=new FormData(e.target), files=f.getAll("photos").filter(x=>x.size), row={user_id:currentUser.id,brand:f.get("brand"),model:f.get("model"),year:Number(f.get("year")),price:Number(f.get("price")),mileage:Number(f.get("mileage"))||null,city:f.get("city"),phone:f.get("phone"),description:f.get("description"),status:"published"};
 let photoUrls=[];
 for(const file of files.slice(0,6)){const path=`${currentUser.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const up=await db.storage.from("car-photos").upload(path,file,{upsert:false});if(up.error){toast("Ошибка загрузки фото: "+up.error.message);return}const pub=db.storage.from("car-photos").getPublicUrl(path);photoUrls.push(pub.data.publicUrl)}
 if(photoUrls.length)row.photo_url=photoUrls[0];
 const {error}=await db.from("listings").insert(row);if(error){toast("Не удалось опубликовать: "+error.message);return}
 hide("listingModal");e.target.reset();toast("Объявление опубликовано!");await loadListings();
};
async function init(){if(db){const {data}=await db.auth.getUser();currentUser=data.user;db.auth.onAuthStateChange((_event,session)=>{currentUser=session?.user||null});}loadListings()}
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
init();