// Apsny Avto — Appwrite edition.
// Fill in the three IDs/endpoint below. Never put an Appwrite API key in browser code.
const APPWRITE_ENDPOINT = "https://REGION.cloud.appwrite.io/v1";
const APPWRITE_PROJECT_ID = "YOUR_PROJECT_ID";
const DATABASE_ID = "apsny_database";
const TABLE_ID = "listings";
const BUCKET_ID = "car_photos";

const configured = !APPWRITE_ENDPOINT.includes("REGION") &&
  !APPWRITE_PROJECT_ID.includes("YOUR_PROJECT_ID") &&
  window.Appwrite;

const client = configured
  ? new Appwrite.Client().setEndpoint(APPWRITE_ENDPOINT).setProject(APPWRITE_PROJECT_ID)
  : null;
const account = client ? new Appwrite.Account(client) : null;
const tablesDB = client ? new Appwrite.TablesDB(client) : null;
const storage = client ? new Appwrite.Storage(client) : null;
const $ = s => document.querySelector(s);
let currentUser = null, allListings = [];

function money(n){return new Intl.NumberFormat("ru-RU").format(Number(n)||0)+" ₽"}
function toast(s){const t=$("#toast");t.textContent=s;t.style.display="block";setTimeout(()=>t.style.display="none",3200)}
function show(id){$("#"+id).classList.add("show")}
function hide(id){$("#"+id).classList.remove("show")}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>hide(b.dataset.close));

$("#addTop").onclick=$("#heroAdd").onclick=()=>{
  if(!client){toast("Сначала заполните настройки Appwrite в app.js");return}
  if(!currentUser){show("authModal");return}
  show("listingModal");
};
document.querySelector('[data-tab="add"]').onclick=()=>$("#addTop").click();
$("#loginBtn").onclick=()=>show("authModal");
document.querySelector('[data-tab="account"]').onclick=()=>{renderAccount();show("accountModal")};
document.querySelector('[data-tab="home"]').onclick=()=>window.scrollTo({top:0,behavior:"smooth"});

function renderAccount(){
  const el=$("#accountInfo");
  el.innerHTML=currentUser
    ? `<p>Вы вошли как <b>${esc(currentUser.email)}</b></p><button class="btn" id="logout">Выйти</button>`
    : `<p>Вы не вошли в аккаунт.</p><button class="btn gold" id="openAuth">Войти / зарегистрироваться</button>`;
  $("#logout")?.addEventListener("click",async()=>{
    try { await account.deleteSession({sessionId:"current"}); currentUser=null; renderAccount(); toast("Вы вышли из аккаунта"); }
    catch(e){toast("Ошибка выхода: "+e.message)}
  });
  $("#openAuth")?.addEventListener("click",()=>{hide("accountModal");show("authModal")});
}

async function loadListings(){
  if(!tablesDB){
    $("#count").textContent="Настройте сервер";
    $("#listings").innerHTML='<div class="empty">Добавьте Endpoint и Project ID в app.js.</div>';
    return;
  }
  try{
    const result=await tablesDB.listRows({
      databaseId:DATABASE_ID,
      tableId:TABLE_ID,
      queries:[Appwrite.Query.equal("status","published"),Appwrite.Query.orderDesc("$createdAt"),Appwrite.Query.limit(100)]
    });
    allListings=result.rows||[];
    $("#count").textContent=allListings.length+" объявлений";
    renderListings();
  }catch(e){
    $("#count").textContent="Ошибка загрузки";
    $("#listings").innerHTML=`<div class="empty">Не удалось загрузить объявления: ${esc(e.message)}. Проверьте ID таблицы и права доступа.</div>`;
  }
}

function renderListings(){
  const q=$("#q").value.trim().toLowerCase(), city=$("#city").value, sort=$("#sort").value;
  let rows=allListings.filter(x=>(!q||`${x.brand} ${x.model}`.toLowerCase().includes(q))&&(!city||x.city===city));
  if(sort==="cheap")rows.sort((a,b)=>a.price-b.price);
  if(sort==="expensive")rows.sort((a,b)=>b.price-a.price);
  $("#count").textContent=rows.length+" объявлений";
  $("#listings").innerHTML=rows.length?rows.map(x=>`<article class="car"><div class="photo">${x.photo_url?`<img src="${esc(x.photo_url)}" alt="${esc(x.brand)} ${esc(x.model)}">`:'<div class="placeholder">🚘</div>'}<span class="tag">${esc(x.city||"Абхазия")}</span></div><div class="car-body"><h3>${esc(x.brand)} ${esc(x.model)}</h3><div class="specs"><span>${x.year||"—"} г.</span><span>${x.mileage?Number(x.mileage).toLocaleString("ru-RU")+" км":"Пробег не указан"}</span></div><div class="price">${money(x.price)}</div><div class="location"><span>${esc(x.description||"Без описания").slice(0,56)}</span><a href="tel:${esc((x.phone||"").replace(/[^+0-9]/g,""))}" style="color:var(--gold2);white-space:nowrap">Позвонить</a></div></div></article>`).join(""):'<div class="empty">Пока нет объявлений. Будьте первым!</div>';
}

$("#searchBtn").onclick=renderListings;
$("#q").oninput=renderListings;
$("#city").onchange=renderListings;
$("#sort").onchange=renderListings;

$("#registerBtn").onclick=async()=>{
  if(!account){toast("Сначала заполните настройки Appwrite в app.js");return}
  const form=$("#authForm"), email=form.elements.email.value.trim(), password=form.elements.password.value;
  if(!email||password.length<8){$("#authHint").textContent="Укажите email и пароль не короче 8 символов.";return}
  $("#authHint").textContent="Создаём аккаунт…";
  try{
    await account.create({userId:Appwrite.ID.unique(),email,password,name:email.split("@")[0]});
    await account.createEmailPasswordSession({email,password});
    currentUser=await account.get();
    hide("authModal");toast("Аккаунт создан!");renderAccount();
  }catch(e){$("#authHint").textContent=e.message}
};

$("#authForm").onsubmit=async e=>{
  e.preventDefault();
  if(!account){toast("Сначала заполните настройки Appwrite в app.js");return}
  const email=e.target.elements.email.value.trim(), password=e.target.elements.password.value;
  $("#authHint").textContent="Входим…";
  try{
    await account.createEmailPasswordSession({email,password});
    currentUser=await account.get();
    hide("authModal");toast("Вы вошли!");renderAccount();
  }catch(err){$("#authHint").textContent=err.message}
};

$("#listingForm").onsubmit=async e=>{
  e.preventDefault();
  if(!tablesDB||!currentUser){toast("Сначала войдите в аккаунт");return}
  const f=new FormData(e.target);
  const row={
    user_id:currentUser.$id,
    brand:String(f.get("brand")),
    model:String(f.get("model")),
    year:Number(f.get("year")),
    price:Number(f.get("price")),
    mileage:Number(f.get("mileage"))||0,
    city:String(f.get("city")),
    phone:String(f.get("phone")),
    description:String(f.get("description")||""),
    photo_url:"",
    status:"published"
  };
  try{
    const files=f.getAll("photos").filter(x=>x.size).slice(0,6);
    if(files.length){
      const uploaded=await storage.createFile({bucketId:BUCKET_ID,fileId:Appwrite.ID.unique(),file:files[0],permissions:[Appwrite.Permission.read(Appwrite.Role.any())]});
      row.photo_url=storage.getFileView({bucketId:BUCKET_ID,fileId:uploaded.$id}).toString();
    }
    await tablesDB.createRow({
      databaseId:DATABASE_ID,
      tableId:TABLE_ID,
      rowId:Appwrite.ID.unique(),
      data:row,
      permissions:[
        Appwrite.Permission.read(Appwrite.Role.any()),
        Appwrite.Permission.update(Appwrite.Role.user(currentUser.$id)),
        Appwrite.Permission.delete(Appwrite.Role.user(currentUser.$id))
      ]
    });
    hide("listingModal");e.target.reset();toast("Объявление опубликовано!");await loadListings();
  }catch(err){toast("Ошибка публикации: "+err.message)}
};

async function init(){
  if(!client){$("#count").textContent="Нужна настройка";$("#listings").innerHTML='<div class="empty">Заполните Endpoint и Project ID в app.js.</div>';return}
  try{currentUser=await account.get()}catch(e){currentUser=null}
  loadListings();
}
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
init();
