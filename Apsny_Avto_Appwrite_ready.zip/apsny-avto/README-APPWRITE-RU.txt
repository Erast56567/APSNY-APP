# Apsny Avto — Appwrite edition

## Важно
Этот архив переключён с Supabase на Appwrite. В браузерный код нельзя вставлять Appwrite API key / secret key. Нужны только Endpoint и Project ID.

## 1. Создайте проект
Откройте https://cloud.appwrite.io/console и создайте проект `Apsny Avto`.

В Project Settings / Overview скопируйте:
- API Endpoint (например `https://fra.cloud.appwrite.io/v1`)
- Project ID

## 2. Добавьте Web platform
В проекте Appwrite: Overview → Add platform → Web.
Добавьте hostname вашего сайта Cloudflare без https:// и без пути, например:
`royal-sky-17ed.erastvnedostupa.workers.dev`
Это важно для CORS.

## 3. Создайте базу
Databases → Create database:
- Name: Apsny Database
- Database ID: `apsny_database`

Внутри создайте Table:
- Name: Listings
- Table ID: `listings`
- Включите Row security (если настройка доступна).

Добавьте столбцы (ID и типы):
- `user_id` — varchar/string, required
- `brand` — varchar/string, required
- `model` — varchar/string, required
- `year` — integer, required
- `price` — integer (если цены целые) или double, required
- `mileage` — integer, required
- `city` — varchar/string, required
- `phone` — varchar/string, required
- `description` — text/string, optional
- `photo_url` — url/string, optional
- `status` — varchar/string, required

Установите Table permissions:
- Read: Any
- Create: Users
- Update: Users (для первого запуска можно оставить на уровне row permissions; не давайте Update/Delete для Any).
- Delete: Users

Приложение создаёт строки с правами чтения для всех и редактирования/удаления только владельцем.

## 4. Создайте Storage bucket
Storage → Create bucket:
- Name: Car photos
- Bucket ID: `car_photos`
- File size limit: 8 MB
- Allowed file extensions: jpg, jpeg, png, webp
- File security: enabled (если есть)
Permissions:
- Create: Users
- Read: Any
- Update/Delete: Users (не Any).

## 5. Заполните app.js
В начале `app.js` замените:
`https://REGION.cloud.appwrite.io/v1` на ваш API Endpoint.
Замените `YOUR_PROJECT_ID` на ваш Project ID.
Оставьте DATABASE_ID, TABLE_ID и BUCKET_ID как есть, если вы использовали указанные выше ID.

## 6. Опубликуйте
Сохраните app.js. Загрузите на Cloudflare Pages/Workers весь распакованный каталог `apsny-avto` (файлы index.html, app.js, manifest.webmanifest, sw.js и папку assets). Не загружайте старую версию ZIP.
После публикации откройте сайт, обновите страницу. Регистрация теперь email + пароль.

## Проверка
1. Создайте аккаунт.
2. Войдите.
3. Добавьте тестовое объявление с фото.
4. Откройте сайт в приватной вкладке: опубликованное объявление должно быть видно всем.
5. Убедитесь, что чужой пользователь не может менять чужое объявление.

## Бесплатный план
Лимиты бесплатного плана Appwrite действуют; при достижении лимитов некоторые операции могут быть остановлены. Проверяйте Usage в консоли. Бесплатные проекты могут приостанавливаться после недели бездействия. Не добавляйте платёжные данные ради запуска.
